#ifndef SNEKTIMER_H
#define SNEKTIMER_H


class SnekTimer
{
public:
    SnekTimer();
    void timerMain();
    void timerHandler();
    void printTimes();

};

#endif // SNEKTIMER_H
